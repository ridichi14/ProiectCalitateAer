
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(express.static('public'));

let sensorData = [];

app.post('/ttn-webhook', (req, res) => {
    const payload = req.body.uplink_message?.decoded_payload;
    if (payload) {
        sensorData.push({
            timestamp: new Date().toISOString(),
            pm10_std: payload.pm10_std,
            pm25_std: payload.pm25_std,
            pm100_std: payload.pm100_std
        });
        if (sensorData.length > 100) sensorData.shift();
    }
    res.sendStatus(200);
});

app.get('/api/data', (req, res) => {
    res.json(sensorData);
});

app.listen(port, () => {
    console.log(`🚀 Serverul rulează pe http://localhost:${port}`);
    console.log(`📊 Site-ul este la: http://localhost:${port}/`);
});
